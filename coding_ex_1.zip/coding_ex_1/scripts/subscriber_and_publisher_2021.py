#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 13 09:53:55 2021

@author: andres
"""

import rospy
from std_msgs.msg import Int32

class listenerNode():
   
    
    number = 0.0
    A=0.0
    def __init__(self):
        self.loop_hertz = 10.0
    
    def run(self):
        self.rate = rospy.Rate(self.loop_hertz)#this line is used to declare the time loop
        rospy.Subscriber("publisher_node_example", Int32, self.callback)
        pub = rospy.Publisher('publisher_subscriber',Int32,queue_size=1)
        while not rospy.is_shutdown():
            A = listenerNode.number * 2
            print("The number is: ",listenerNode.number)
            pub.publish(A)
            self.rate.sleep()
            
   
    def callback(self,msg):
        listenerNode.number = msg.data
        print("msg is",msg)
        rospy.loginfo("number %s", self.number)
        

    
   
# Main function.
if __name__ == '__main__':
    # Initialize the node and name it.
    rospy.init_node('rospy_listener_example', anonymous = True)
    ne = listenerNode()
    ne.run()