#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 13 10:06:12 2021

@author: andres
"""

import rospy
from std_msgs.msg import Int32

rospy.init_node("printer_node")
print("Hi ROS!!")
